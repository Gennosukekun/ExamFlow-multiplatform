# ExamFlow Italia v7 — Android + iPhone

Questa versione contiene entrambi i progetti:
- `app/` + Gradle: Android (APK/AAB)
- `ios/ExamFlowItalia.xcodeproj`: iPhone (Xcode, iOS 15+)

La UI e la logica ExamFlow sono condivise tramite gli stessi file HTML/CSS/JS. Il progetto iOS usa WKWebView e un bridge Swift compatibile con il bridge Android per login via codice, sincronizzazione cloud, Quiz AI e promemoria di studio.

## iPhone
Aprire `ios/ExamFlowItalia.xcodeproj` con Xcode su macOS. In Signing & Capabilities selezionare il proprio Team Apple e, se necessario, cambiare il Bundle Identifier. Collegare un iPhone e premere Run. Per TestFlight/App Store creare un Archive e firmarlo con Apple Developer.

Nota: una IPA installabile/distribuibile richiede firma Apple; non è inclusa una firma o un certificato nel progetto.
