import UIKit
import WebKit
import UserNotifications

final class ViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate {
    private var webView: WKWebView!
    private let base = "https://examflow-4zkm.hatchable.site"

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        let content = WKUserContentController()
        content.add(self, name: "examflow")
        let shim = """
        window.AndroidBridge={};
        ['authStatus','startLogin','verifyCode','signOut','loadCloud','saveCloud','generateQuiz'].forEach(function(m){
          window.AndroidBridge[m]=function(){var a=[].slice.call(arguments),cb=a.pop();window.webkit.messageHandlers.examflow.postMessage({method:m,args:a,callbackId:cb});};
        });
        window.AndroidBridge.setStudyReminders=function(enabled){window.webkit.messageHandlers.examflow.postMessage({method:'setStudyReminders',args:[!!enabled]});};
        """
        content.addUserScript(WKUserScript(source: shim, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        let cfg = WKWebViewConfiguration(); cfg.userContentController = content; cfg.websiteDataStore = .default()
        webView = WKWebView(frame: .zero, configuration: cfg); webView.navigationDelegate = self
        webView.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(webView)
        NSLayoutConstraint.activate([webView.topAnchor.constraint(equalTo:view.topAnchor),webView.bottomAnchor.constraint(equalTo:view.bottomAnchor),webView.leadingAnchor.constraint(equalTo:view.leadingAnchor),webView.trailingAnchor.constraint(equalTo:view.trailingAnchor)])
        if let url = Bundle.main.url(forResource:"index", withExtension:"html", subdirectory:"Web") { webView.loadFileURL(url, allowingReadAccessTo:url.deletingLastPathComponent()) }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let b=message.body as? [String:Any], let method=b["method"] as? String else{return}
        let args=b["args"] as? [Any] ?? [], cb=b["callbackId"] as? String
        if method=="setStudyReminders" { setReminder((args.first as? Bool) ?? false); return }
        var path="", http="GET", body:Any?=nil
        switch method {
        case "authStatus": path="/api/auth/get-session"
        case "startLogin": path="/api/auth/login/start";http="POST";body=["email":args.first as? String ?? ""]
        case "verifyCode": path="/api/auth/login/verify-code";http="POST";body=["email":args.count>0 ? args[0] as? String ?? "":"","code":args.count>1 ? args[1] as? String ?? "":""]
        case "signOut": path="/api/auth/sign-out";http="POST";body=[:]
        case "loadCloud": path="/api/account/state"
        case "saveCloud": path="/api/account/state";http="PUT"; if let s=args.first as? String, let d=s.data(using:.utf8), let o=try? JSONSerialization.jsonObject(with:d){body=["state":o]}
        case "generateQuiz": path="/api/generate-quiz";http="POST";if let s=args.first as? String,let d=s.data(using:.utf8){body=try? JSONSerialization.jsonObject(with:d)}
        default:return
        }
        request(path:path,method:http,body:body,callbackId:cb)
    }

    private func request(path:String,method:String,body:Any?,callbackId:String?){
        guard let u=URL(string:base+path) else{return};var r=URLRequest(url:u);r.httpMethod=method;r.setValue("application/json",forHTTPHeaderField:"Accept")
        if let body=body {r.setValue("application/json; charset=utf-8",forHTTPHeaderField:"Content-Type");r.httpBody=try? JSONSerialization.data(withJSONObject:body)}
        URLSession.shared.dataTask(with:r){[weak self] data,res,err in
            let status=(res as? HTTPURLResponse)?.statusCode ?? 0;var out:[String:Any]=["status":status,"ok":(200..<300).contains(status)]
            if let data=data, let obj=try? JSONSerialization.jsonObject(with:data){out["data"]=obj}else if let err=err{out["error"]=err.localizedDescription}
            let d=(try? JSONSerialization.data(withJSONObject:out)) ?? Data("{}".utf8);let text=String(data:d,encoding:.utf8) ?? "{}"
            if let cb=callbackId {DispatchQueue.main.async{self?.callback(cb:cb,ok:err == nil,data:text)}}
        }.resume()
    }
    private func callback(cb:String,ok:Bool,data:String){
        let c=String(data:try! JSONSerialization.data(withJSONObject:cb),encoding:.utf8)!;let d=String(data:try! JSONSerialization.data(withJSONObject:data),encoding:.utf8)!
        webView.evaluateJavaScript("window.nativeCallback(\(c),\(ok ? "true":"false"),\(d));")
    }
    private func setReminder(_ enabled:Bool){
        let center=UNUserNotificationCenter.current();center.removePendingNotificationRequests(withIdentifiers:["examflow-study"]);guard enabled else{return}
        center.requestAuthorization(options:[.alert,.sound,.badge]){ok,_ in guard ok else{return};let c=UNMutableNotificationContent();c.title="ExamFlow Italia";c.body="È il momento della tua sessione di studio.";c.sound=.default;var dc=DateComponents();dc.hour=19;let t=UNCalendarNotificationTrigger(dateMatching:dc,repeats:true);center.add(UNNotificationRequest(identifier:"examflow-study",content:c,trigger:t))}
    }
}
