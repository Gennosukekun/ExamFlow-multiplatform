ExamFlow Italia - restyling completo grafica e menu

Modifiche:
- Home più pulita con 6 azioni principali
- nuovo menu "Altri strumenti" per funzioni secondarie
- menu strumenti in griglia moderna
- bottom navigation flottante
- header e stato sync ridisegnati
- card, statistiche e hero uniformati
- form e pulsanti più moderni
- quiz, profilo, calendario, flashcard, appunti, esami e cronologia uniformati
- modali bottom-sheet più curate
- login ridisegnato
- dark mode migliorata
- safe-area Android preservate
- nessuna funzione rimossa

Controllo JavaScript: OK
