# ExamFlow — PROJECT_CONTEXT

## Obiettivo del progetto
ExamFlow è un'app Android per organizzare lo studio universitario e arrivare preparati agli esami.

Questa cartella rappresenta la versione da cui continuare. Non rifare il progetto da zero.

## Stack e architettura
- App Android con WebView locale.
- Frontend locale in `app/src/main/assets`.
- Backend Hatchable usato per:
  - autenticazione passwordless via email OTP;
  - sincronizzazione cloud;
  - quiz AI.
- L'interfaccia dell'app viene caricata localmente nell'APK per non mostrare il branding Hatchable.
- Il bridge Android nativo gestisce le chiamate HTTP verso il backend Hatchable.
- Repository GitHub previsto per la build APK tramite GitHub Actions.

## Backend Hatchable
Backend principale:
`https://examflow-4zkm.hatchable.site`

Endpoint usati:
- `/api/auth/login/start`
- `/api/auth/login/verify-code`
- `/api/auth/get-session`
- `/api/auth/sign-out`
- `/api/account/state`
- `/api/generate-quiz`

L'autenticazione è passwordless:
1. inserimento email;
2. invio codice OTP;
3. verifica codice;
4. sessione mantenuta tramite cookie.

Non aggiungere password.

## Funzioni presenti
- Piano di studio.
- Recupero ritardi.
- Quiz AI.
- Quaderno errori.
- Ripasso intelligente.
- Statistiche.
- Mastery per argomento.
- Modalità salvataggio esame / rescue mode.
- Streak e XP.
- Focus / Pomodoro.
- Obiettivo settimanale.
- Flashcard.
- Ripetizione dilazionata per flashcard.
- Appunti.
- Checklist giornaliera.
- Gestione esami multipli.
- Conto alla rovescia esami.
- Calendario.
- Ricerca globale.
- Materiali / link utili.
- Cronologia attività.
- Achievement.
- Backup JSON.
- Import backup.
- Guest mode.
- Sync cloud.
- Tema chiaro/scuro.
- Notifiche studio Android.

## Stato grafico
Usare come base la grafica della versione:
`ExamFlow_Italia_UI_Complete`

Questa è la versione approvata prima del tentativo di restyling Material Design 3.

NON usare il restyling Material Design 3: è stato rifiutato.

Ultima richiesta grafica non completata:
- migliorare leggermente la schermata login;
- rendere ben visibile il testo “Accedi con la tua e-mail”.

Questa modifica NON è stata applicata perché il lavoro è stato interrotto.

## Preferenze di design
- Interfaccia moderna ma non eccessivamente “Material”.
- Gradienti blu/viola ammessi.
- Aspetto pulito.
- Menu chiari.
- Evitare schermate troppo affollate.
- Mantenere una UI coerente su Home, quiz, profilo, calendario, appunti e login.
- Non mostrare branding Hatchable dentro l'app Android.

## GitHub Actions
La cartella `.github/workflows` è inclusa.

Il workflow corretto NON deve usare:
`android-actions/setup-android@v3`

Questo causava:
`Warning: Failed to find package 'tools'`

La build deve usare:
- Java 17;
- Android SDK 35;
- build-tools 35.0.0;
- Gradle 8.9;
- `actions/upload-artifact@v4`.

Il file ZIP Android atteso dal workflow deve chiamarsi:
`ExamFlow_Italia_Android_Project.zip`

## Nota sulla build
Non dare per riuscita una build finché GitHub Actions non mostra:
- job completato con successo;
- artifact APK generato.

## Notifiche Android
È presente una logica di reminder studio.
Verificare in futuro il permesso runtime `POST_NOTIFICATIONS` su Android 13+.

## Quiz AI
Il frontend passa anche il tipo di quiz:
- scelta multipla;
- vero/falso;
- risposta breve;
- misto.

Il backend potrebbe non gestire ancora perfettamente tutti questi tipi.
Verificare prima di dichiarare che funzionano tutti.

## Sincronizzazione
Lo snapshot cloud include dati principali dell'app:
- piano;
- errori;
- statistiche;
- streak;
- mastery;
- focus;
- obiettivi;
- flashcard;
- appunti;
- checklist;
- esami;
- materiali;
- tema;
- notifiche.

## Vincoli importanti
- Non introdurre servizi a pagamento.
- Non autorizzare acquisti o abbonamenti.
- Non inserire chiavi API direttamente nel codice.
- Non esporre segreti.
- Non sostituire Hatchable con altri backend senza richiesta esplicita.
- Non rimuovere funzioni esistenti senza motivo.
- Non cambiare il link/backend Hatchable senza richiesta.

## Modalità di lavoro consigliata
Quando si continua il progetto:
1. analizzare prima la struttura;
2. non rifare il progetto da zero;
3. mantenere compatibilità con backend e dati salvati;
4. fare modifiche incrementalmente;
5. controllare sempre la sintassi JavaScript;
6. evitare modifiche massive non testate;
7. prima di una build, verificare workflow, nome ZIP e struttura del progetto.

## Prompt consigliato per una nuova chat
Puoi usare questo messaggio:

> Questo è il mio progetto ExamFlow. Continua a lavorare su questa versione senza rifarlo da zero. Prima leggi `PROJECT_CONTEXT.md`, poi analizza la struttura del progetto. Mantieni tutte le funzioni esistenti, la compatibilità con Hatchable, il login OTP, il cloud sync e il workflow Android. Non usare servizi a pagamento. Non applicare il restyling Material Design 3. Prima di modificare qualcosa dimmi in breve cosa toccherai, poi procedi direttamente.

## v6.2 login contrast fix
- Forced the login title “Accedi con la tua email” to dark high-contrast text on the white login card, including when dark mode was previously active.
- Increased label contrast on the login card.
