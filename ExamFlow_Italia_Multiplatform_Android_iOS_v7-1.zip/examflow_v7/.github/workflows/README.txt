Cartella workflow GitHub Actions per ExamFlow.

Percorso corretto nel repository:
.github/workflows/build-apk.yml

Il file ZIP del progetto Android deve trovarsi nella root del repository con questo nome:
ExamFlow_Italia_Android_Project.zip
