ExamFlow Italia - build Android standalone senza branding Hatchable

- L'interfaccia è inclusa direttamente nell'APK.
- Nessuna pagina Hatchable viene mostrata nell'app.
- Login reale con email + codice monouso tramite bridge Android.
- Sessione autenticata mantenuta tramite cookie nativi.
- Sincronizzazione cloud di piano, errori, statistiche, streak e tema.
- Quiz AI tramite backend esistente.
- Modalità ospite disponibile.
- Icona ExamFlow inclusa.

Per compilare:
gradle assembleDebug
